# Azure Network Assessment Dashboard

**Run:** 00000000-0000-4000-8000-000000000080
**Assessment status:** PARTIAL_CONFIGURATION_ASSESSMENT
**Configuration window:** 2026-10-13T15:00:00Z through 2026-10-13T15:00:00Z

Prototype, read-only configuration assessment; not effective connectivity, customer compliance or operational-health certification.

## Evidence and source coverage

[Assessment JSON](assessment.json) is authoritative; [observations](observed-network.json) contain no interpreted findings.

| Operation | Status | Retained rows | Issues |
|---|---|---:|---|
| subscription-context | succeeded | 1 |  |
| vnets | succeeded | 1 |  |
| subnets | succeeded | 1 |  |
| peerings | succeeded | 0 |  |
| route-tables | succeeded | 0 |  |
| routes | succeeded | 0 |  |
| nsgs | succeeded | 1 |  |
| nsg-rules | succeeded | 1 |  |
| ip-attachments | succeeded | 1 |  |
| private-endpoints | succeeded | 0 |  |
| private-endpoint-connections | succeeded | 0 |  |
| private-dns-zones | succeeded | 0 |  |
| private-dns-links | succeeded | 0 |  |
| private-dns-groups | succeeded | 0 |  |
| private-link-services | succeeded | 0 |  |
| vnet-dns-settings | succeeded | 0 |  |
| dns-resolvers | succeeded | 0 |  |
| dns-rulesets | succeeded | 0 |  |
| dns-inbound-endpoints | succeeded | 0 |  |
| dns-outbound-endpoints | succeeded | 0 |  |
| dns-forwarding-rules | succeeded | 0 |  |
| dns-ruleset-links | succeeded | 0 |  |
| storage-service-arm | succeeded | 0 |  |
| vault-service-arm | succeeded | 0 |  |
| registry-service-arm | succeeded | 0 |  |
| nsp-perimeters | succeeded | 0 |  |
| nsp-profiles | succeeded | 0 |  |
| nsp-associations | succeeded | 0 |  |
| nsp-rules | succeeded | 0 |  |
| reference-firewalls | succeeded | 0 |  |
| reference-hybrid | succeeded | 0 |  |
| reference-monitoring | succeeded | 0 |  |
| reference-public-ips | succeeded | 1 |  |
| repeated-zone-record-metadata | succeeded | 0 |  |

## Specialist review coverage

### Topology, addressing and peering

**Observed state:** configuration-reviewed-with-gaps; returned rows: 2
**Expected state:** Applicable declared requirements and supported platform behavior; owner-specific intent is not assumed.
**Risk:** Uncollected effective/operational evidence limits conclusions; configured references are not actual traffic.
**Dependencies / considerations:** Owner connectivity intent; Uncollected external networks; Effective transit and reachability

### Configured routing and egress

**Observed state:** configuration-reviewed-with-gaps; returned rows: 1
**Expected state:** Applicable declared requirements and supported platform behavior; owner-specific intent is not assumed.
**Risk:** Uncollected effective/operational evidence limits conclusions; configured references are not actual traffic.
**Dependencies / considerations:** NIC effective routes; Learned routes and actual egress/return paths

### NSG rules and ingress context

**Observed state:** configuration-reviewed-with-gaps; returned rows: 4
**Expected state:** Applicable declared requirements and supported platform behavior; owner-specific intent is not assumed.
**Risk:** Uncollected effective/operational evidence limits conclusions; configured references are not actual traffic.
**Dependencies / considerations:** Effective NIC/subnet/admin rules; Listeners, source paths and actual reachability; Rule hit-count coverage

### Private Endpoints and DNS

**Observed state:** no-resources-returned-in-scoped-index; returned rows: 0
**Expected state:** Applicable declared requirements and supported platform behavior; owner-specific intent is not assumed.
**Risk:** Uncollected effective/operational evidence limits conclusions; configured references are not actual traffic.
**Dependencies / considerations:** Actual client resolution and traffic; External DNS dependencies; Owner-approved public exceptions

### Existing telemetry and recorded context

**Observed state:** no-resources-returned-in-scoped-index; returned rows: 0
**Expected state:** Applicable declared requirements and supported platform behavior; owner-specific intent is not assumed.
**Risk:** Uncollected effective/operational evidence limits conclusions; configured references are not actual traffic.
**Dependencies / considerations:** Validated log-table/window coverage; Traffic, latency and rule-usage evidence; Recorded context not supplied

| Existing monitoring resource | Configured enabled | Data coverage verified |
|---|---|---|

### Firewall and hybrid connectivity

**Observed state:** no-resources-returned-in-scoped-index; returned rows: 0
**Expected state:** Applicable declared requirements and supported platform behavior; owner-specific intent is not assumed.
**Risk:** Uncollected effective/operational evidence limits conclusions; configured references are not actual traffic.
**Dependencies / considerations:** Complete firewall rule and hit-count evidence; BGP/learned/effective routes; Tunnel/traffic behavior

| Firewall/policy | Rule review | Effective enforcement |
|---|---|---|

| Hybrid resource | Reported coarse connection state | Effective routing |
|---|---|---|

These indexed states do not establish traffic, BGP exchange or an outage.

## Findings

### NET-5d69b9d081226c9cc94ea80e - Broad-source inbound management/database rule requires contextual validation

**Check:** NET-NSG-002 / 1.0.0
**Record / impact severity:** potentialRisk / None
**Confidence:** medium
**Observed state:** Returned custom inbound Allow configuration matches a broad source and review port(s) 22; ingress evidence: configured-public-ip-nic-subnet-reference.
**Expected state:** Validate the owner-approved source scope and management-access design; no customer policy is assumed.
**Risk:** The configuration could permit broad-source access if other path and enforcement conditions allow. Neither this rule nor the collected attachment references establish actual reachability.
**Recommendation:** Validate intended sources, effective NIC/subnet/admin rules, routing and listeners before assigning impact or planning changes.
**Dependencies / considerations:** Owner source/port applicability and documented exceptions; Earlier-priority and effective NIC/subnet rules; Security-admin overrides; Effective routes and actual listeners; No automatic remediation

**Configured ingress evidence:** configured-public-ip-nic-subnet-reference
**Actual reachability:** UNKNOWN

- [Retained source](sources/00000000-0000-4000-8000-000000000057/selected-input.json) `/collections/2/rows/0`
- [Retained source](sources/00000000-0000-4000-8000-000000000057/selected-input.json) `/collections/7/rows/0`
- [Retained source](sources/00000000-0000-4000-8000-000000000057/selected-input.json) `/collections/6/rows/0`
- [Retained source](sources/00000000-0000-4000-8000-000000000057/selected-input.json) `/collections/8/rows/0`
- [Retained source](sources/00000000-0000-4000-8000-000000000057/selected-input.json) `/collections/32/rows/0`

### NET-66e69518ee81f9003a937d41 - Permission-wide completeness and operational health remain unverified

**Check:** NET-COVERAGE-001 / 1.0.0
**Record / impact severity:** evidenceGap / None
**Confidence:** low
**Observed state:** Resource Graph returns accessible indexed configuration; effective behavior and telemetry are deferred.
**Expected state:** No owner-specific requirement supplied.
**Risk:** Zero detected problems cannot certify network health or complete subscription visibility.
**Recommendation:** Confirm authorized scope and choose targeted operational deep dives where needed.
**Dependencies / considerations:** Customer connectivity intent and authorized evidence access


### NET-7e71f6d9363c21639430ace4 - Actual DNS client and forwarding behavior remain unverified

**Check:** NET-DNS-PATH-001 / 1.0.0
**Record / impact severity:** evidenceGap / None
**Confidence:** low
**Observed state:** Only approved VNet and Azure DNS Private Resolver configuration was selected; custom/on-premises DNS internals, client overrides and live lookups were not collected.
**Expected state:** No owner-specific requirement supplied.
**Risk:** Client visibility, forwarding effectiveness, resolution and safe cleanup cannot be certified.
**Recommendation:** Confirm customer DNS architecture and external dependencies, then choose explicitly authorized evidence; do not enable diagnostics or run active lookups.
**Dependencies / considerations:** Customer connectivity intent and authorized evidence access


### NET-4ba31dd912541a576709d26f - Service-to-Private-DNS planning comparison is available

**Check:** NET-DNS-PLAN-001 / 1.0.0
**Record / impact severity:** contextValidation / None
**Confidence:** high
**Observed state:** Scoped service resources=0; collected DNS zones=0; DNS-hosting scope=declared-accessible-results.
**Expected state:** No owner-specific requirement supplied.
**Risk:** Service use, endpoint consumers and central/custom DNS must be confirmed before planning private-access expansion.
**Recommendation:** Review the service planning matrix with customer owners; select required service features/subresources and explicit central-DNS/consumer scopes. Never infer missing endpoints because zones were not observed.
**Dependencies / considerations:** Customer connectivity intent and authorized evidence access


### NET-00fd72eb3820ba9d0d99f26d - NSP scope or association coverage does not establish effective controls

**Check:** NET-NSP-001 / 1.0.0
**Record / impact severity:** evidenceGap / None
**Confidence:** low
**Observed state:** Collected perimeters=0; associations=0; outcomes are recorded.
**Expected state:** No owner-specific requirement supplied.
**Risk:** Alternative-control coverage remains UNKNOWN.
**Recommendation:** Review recorded scope/permission/API/parent coverage before drawing service-specific conclusions.
**Dependencies / considerations:** Customer connectivity intent and authorized evidence access



## Framework and technical lineage

- Usman Mahmood / Azure Networking Assessment Agent: scope/evidence/requirements workflow; dashboard and contextual findings, positives, assumptions and artifact verification; revision `624bd5c3bf5bd5b8df625cc111c94531dff19148`.
- Daniel Mauser / Network Desk: Azure-only evidence questions and specialist review sequence; no mutation, active tests or blanket severity heuristics; revision `4104279fa4707c24e6038b35b2779fecfdd11eea`.

## Limitations

- Fresh configuration is not an atomic environment snapshot or actual packet flow.
- Indexed data can lag; absence is limited to returned accessible results, not global completeness.
- Effective rules/routes, listeners, BGP/learned routes and validated rule usage are not collected by this pass.
- Private Endpoint approval/DNS configuration is not client resolution or private-only access.
- No customer architecture, IaC authority, business criticality or public-access exceptions were invented.
- No resource, logging, monitor, role or identity changes; no active tests or automatic remediation.
- No memory maintenance or schedule is part of this workflow.
